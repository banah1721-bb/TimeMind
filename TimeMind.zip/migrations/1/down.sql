
DROP INDEX idx_user_preferences_user_id;
DROP INDEX idx_study_sessions_schedule;
DROP INDEX idx_study_sessions_user_id;
DROP INDEX idx_tasks_deadline;
DROP INDEX idx_tasks_user_id;
DROP TABLE user_preferences;
DROP TABLE study_sessions;
DROP TABLE tasks;
